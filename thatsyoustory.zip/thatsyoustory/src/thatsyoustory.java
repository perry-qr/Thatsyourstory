
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
 *
 * @author Perry
 */

public class thatsyoustory extends JFrame {
    public static void main(String args[]) {
        /*
         ***********
         * the part of the GTerm*
         ***********
         */
        game n = new game();
        GTerm feiwu = new GTerm(1000, 700);
        feiwu.setBackgroundColor(0, 0, 0);
        feiwu.setFontColor(225, 225, 225);
        feiwu.setXY(250, 0);
        feiwu.setFontSize(20);
        feiwu.println("This is a waste frame. ");
        feiwu.println("The user name is Perry");
        feiwu.println("The passworld is 123");
        feiwu.setFont(null, 0, 20);
        String paw = feiwu.getInputString("Please enter your password:");
        String person = feiwu.getInputString("Please enter your password:");
        if (paw != "123") {
            feiwu.println("welcome");
            feiwu.println(person);
            feiwu.showMessageDialog(person + "the game is about to begin!");
            feiwu.setFontColor(225, 0, 0);
            feiwu.setFontSize(20);
            feiwu.clear();
            feiwu.setXY(250, 0);
            feiwu.println("It will shut down in 5000 milliseconds");
            try {
                Thread.sleep(5000);
            } catch (Exception e) { }
            n.getinfo();
            feiwu.dispose();
        } else {
            feiwu.showMessageDialog("wrong Password!");
            String apaw = feiwu.getInputString("Please enter your password:");
            if (apaw != "123") {
                feiwu.println("welcome");
                feiwu.println(person);
                feiwu.showMessageDialog(person + "the game is about to begin!");
                feiwu.setFontColor(225, 0, 0);
                feiwu.setFontSize(20);
                feiwu.clear();
                feiwu.setXY(250, 0);
                feiwu.println("It will shut down in 5000 milliseconds");
                try {
                    Thread.sleep(5000);
                } catch (Exception e) { }
                n.getinfo();
                feiwu.dispose();}
            else {
                feiwu.showMessageDialog("wrong Password!");
                String bpaw = feiwu.getInputString("Please enter your password:");
                if (bpaw != "123") {
                    feiwu.println("welcome");
                    feiwu.println(person);
                    feiwu.showMessageDialog(person + "the game is about to begin!");
                    feiwu.setFontColor(225, 0, 0);
                    feiwu.setFontSize(20);
                    feiwu.clear();
                    feiwu.setXY(250, 0);
                    feiwu.println("It will shut down in 5000 milliseconds");
                    try {
                        Thread.sleep(5000);
                    } catch (Exception e) { }
                    n.getinfo();
                    feiwu.dispose();
                } else {
                    feiwu.showMessageDialog("Password error accumulates 3 times, about to exit!");
                    System.exit(0);
                }
            }
        }
    }
}
class game{
    public void getinfo(){
        JFrame story = new JFrame("that's you story");
        story.setResizable(false);
        story.setSize(1000, 700);
        story.setVisible(true);
        story.setLocationRelativeTo(null);
        story.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        story.setLayout(new BorderLayout());    //Set the layout for the Frame window to be BorderLayout
        JLabel rule = new JLabel("<html><body><p align=\"center\">Welcome to the game of survival, young man<br/>Let us begin our escape<br/>The game rules are as follows:<br/>Just click on Button<br/>Due to the time, the lazy author only did a little, look forward to the author's update!</p></body></html>", JLabel.CENTER);
        rule.setOpaque(true);
        rule.setBackground(Color.black);
        rule.setForeground(Color.white);
        rule.setPreferredSize(new Dimension(1000, 100));
        JLabel p2 = new JLabel(new ImageIcon("img/f.jpg"));
        JPanel p3 = new JPanel() {
            public void paintComponent(Graphics g) {
                ImageIcon icon = new ImageIcon("img/bg.jpg");
                //The image varies with the size of the form
                g.drawImage(icon.getImage(), 0, 0, this.getSize().width, this.getSize().height, this);
            }
        };
        JLabel txt = new JLabel("<html><body><p align=\"center\"><br/>Welcome to the game of survival, young man<br/>Let us begin our escape<br/>The game rules are as follows|<br/>the lazy author only did a little<br/>look forward to the author's update!<br/></p></body></html>");
        txt.setFont(new Font("Dialog",Font.BOLD  , 15));
        txt.setForeground(Color.white);
        p3.add(txt);    //Add TXT to the JPanel container
        txt.setOpaque(false);
        JLabel p4 = new JLabel(new ImageIcon("img/s.jpg"));
        Image image = new ImageIcon("img/3.jpg").getImage();
        JPanel operate = new BackgroundPanel(image);
        operate.setPreferredSize(new Dimension(1000, 100));
        JButton yes = new JButton("YES");
        JButton no = new JButton("No");
        operate.add(yes);
        operate.add(no);
        operate.validate();
        operate.repaint();
        //operate.revalidate();
        story.add(rule, BorderLayout.NORTH);
        story.add(p2, BorderLayout.WEST);
        story.add(p3, BorderLayout.CENTER);
        story.add(p4, BorderLayout.EAST);
        story.add(operate, BorderLayout.SOUTH);
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("file");
        JMenu editMenu = new JMenu("compile");
        JMenu elseMenu = new JMenu("additional");
        JMenu aboutMenu = new JMenu("about");
        // A level menu is added to the menu bar
        menuBar.add(fileMenu);
        menuBar.add(editMenu);
        menuBar.add(elseMenu);
        menuBar.add(aboutMenu);
        JMenuItem newMenuItem = new JMenuItem("New Game");
        JMenuItem attributeMenuItem = new JMenuItem("attribute");
        JMenuItem exitMenuItem = new JMenuItem("exit");
        // Sub menus are added to the primary menu
        fileMenu.add(newMenuItem);
        fileMenu.add(attributeMenuItem);
        fileMenu.addSeparator();       // Add a divider
        fileMenu.add(exitMenuItem);
        JMenuItem adminMenuItem = new JMenuItem("Administrator mode");
        JMenuItem pasteMenuItem = new JMenuItem("To be determined");
        // Sub menus are added to the primary menu
        editMenu.add(adminMenuItem);
        editMenu.add(pasteMenuItem);
        final JCheckBoxMenuItem checkBoxMenuItem = new JCheckBoxMenuItem("Whether to turn on the music");
        final JRadioButtonMenuItem radio01 = new JRadioButtonMenuItem("In the daytime mode", true);
        final JRadioButtonMenuItem radio02 = new JRadioButtonMenuItem("In the night mode");
        // Sub menus are added to the primary menu
        elseMenu.add(checkBoxMenuItem);
        elseMenu.addSeparator();                // Add a divider
        elseMenu.add(radio01);
        elseMenu.add(radio02);
        // Two of these are radio button sub menus. To make radio buttons look like radio buttons, you need to put them into a group of buttons
        ButtonGroup btnGroup = new ButtonGroup();
        btnGroup.add(radio01);
        btnGroup.add(radio02);
        // Default the first radio button sub menu is selected
        radio01.setSelected(true);
        newMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("New start is clicked");
            }
        });
        // Sets the listener to which the "Open" sub menu is clicked
        attributeMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Properties are clicked");
                JOptionPane.showMessageDialog(null, "To develop", "warning", JOptionPane.WARNING_MESSAGE);
            }
        });
        // Sets the listener to which the "Exit" sub menu is clicked
        exitMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Exit is clicked");
                System.exit(0);
            }
        });
        adminMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("The administrator is clicked");
                String pw = JOptionPane.showInputDialog("Please enter your password:");
                int password = Integer.parseInt(pw);
                if (password == 123456) {
                    JOptionPane.showMessageDialog(null, "Welcome back!", "welcome", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "10/5000 \r\n" + 
                    		"Hum! You are not my master!", "warning", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        checkBoxMenuItem.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                System.out.println("Whether the check box is selected: " + checkBoxMenuItem.isSelected());
            }
        });
        radio01.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
//                story.getContentPane().setVisible(true);
//                story.setBackground(Color.WHITE);
            }
        });
        radio02.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
//                story.getContentPane().setVisible(true);
//                story.setBackground(Color.BLACK);
            }
        });


        aboutMenu.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                JOptionPane.showMessageDialog(null, "<html><body><p align=\\\"center\\\">Please contact the developer if you have any questions。<br/>contact us：123@outlook.com</p></body></html>", "about", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        no.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
                System.exit(0);
            }
        });
        yes.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {

                JFrame story1 = new JFrame("that's you story");
                story1.setResizable(false);
                story1.setSize(1000, 700);
                story1.setVisible(true);
                story1.setLocationRelativeTo(null);
                story1.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
                story1.setLayout(new BorderLayout());    //Set the layout for the Frame window to be BorderLayout
                JLabel rule = new JLabel("<html><body><p align=\"center\">Welcome to the game of survival, young man<br/>Let us begin our escape<br/>The rules are as follows：<br/>click the Button<br/>Due to the time, the lazy author only did a little, look forward to the author's update!</p></body></html>", JLabel.CENTER);
                rule.setOpaque(true);
                rule.setBackground(Color.black);
                rule.setForeground(Color.white);
                rule.setPreferredSize(new Dimension(1000, 100));
                JLabel p2 = new JLabel(new ImageIcon("img/f.jpg"));
                JPanel p3 = new JPanel() {
                    public void paintComponent(Graphics g) {
                        ImageIcon icon = new ImageIcon("img/bg.jpg");
                        // The image varies with the size of the form
                        g.drawImage(icon.getImage(), 0, 0, this.getSize().width, this.getSize().height, this);
                    }
                };
                JLabel txt = new JLabel("<html><body><p align=\\\"center\\\"><br/>You're walking down the road on a dark morning.<br/>Suddenly there was a roar in front of him.<br/>your choice is:<br/>[There seems to be something over there, <br/>go and have a look.]<br/><br/>[That's terrible.<br/> Let's go home.]</p></body></html>");
                txt.setFont(new Font("Dialog",Font.BOLD  , 15));
                txt.setForeground(Color.white);
                p3.add(txt);    //Add TXT to the JPanel container
                txt.setOpaque(false);
                JLabel p4 = new JLabel(new ImageIcon("img/s.jpg"));
                Image image = new ImageIcon("img/3.jpg").getImage();
                JPanel operate = new BackgroundPanel(image);
                operate.setPreferredSize(new Dimension(1000, 100));
                JButton yes = new JButton("go home");
                JButton no = new JButton("Go forward");
                operate.add(yes);
                operate.add(no);
                operate.validate();
                operate.repaint();
                //operate.revalidate();
                story1.add(rule, BorderLayout.NORTH);
                story1.add(p2, BorderLayout.WEST);
                story1.add(p3, BorderLayout.CENTER);
                story1.add(p4, BorderLayout.EAST);
                story1.add(operate, BorderLayout.SOUTH);
                JMenuBar menuBar = new JMenuBar();
                JMenu fileMenu = new JMenu("file");
                JMenu editMenu = new JMenu("compile");
                JMenu elseMenu = new JMenu("additional");
                JMenu aboutMenu = new JMenu("about");
                // A level menu is added to the menu bar
                menuBar.add(fileMenu);
                menuBar.add(editMenu);
                menuBar.add(elseMenu);
                menuBar.add(aboutMenu);
                JMenuItem newMenuItem = new JMenuItem("New Game");
                JMenuItem attributeMenuItem = new JMenuItem("attribute");
                JMenuItem exitMenuItem = new JMenuItem("Exit");
                // Sub menus are added to the primary menu
                fileMenu.add(newMenuItem);
                fileMenu.add(attributeMenuItem);
                fileMenu.addSeparator();       // Add a divider
                fileMenu.add(exitMenuItem);
                JMenuItem adminMenuItem = new JMenuItem("Administrator mode");
                JMenuItem pasteMenuItem = new JMenuItem("To be determined");
                // Sub menus are added to the primary menu
                editMenu.add(adminMenuItem);
                editMenu.add(pasteMenuItem);
                final JCheckBoxMenuItem checkBoxMenuItem = new JCheckBoxMenuItem("Whether to turn on the music");
                final JRadioButtonMenuItem radio01 = new JRadioButtonMenuItem("In the daytime mode", true);
                final JRadioButtonMenuItem radio02 = new JRadioButtonMenuItem("In the night mode");
                // Sub menus are added to the primary menu
                elseMenu.add(checkBoxMenuItem);
                elseMenu.addSeparator();                // Add a divider
                elseMenu.add(radio01);
                elseMenu.add(radio02);
                // Two of these are radio button sub menus. To make radio buttons look like radio buttons, you need to put them into a group of buttons
                ButtonGroup btnGroup = new ButtonGroup();
                btnGroup.add(radio01);
                btnGroup.add(radio02);
                // Default the first radio button sub menu is selected
                radio01.setSelected(true);
                newMenuItem.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        System.out.println("New start is clicked");
                    }
                });
                // Sets the listener to which the "Open" sub menu is clicked
                attributeMenuItem.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        System.out.println("Properties are clicked");
                        JOptionPane.showMessageDialog(null, "To develop", "warning", JOptionPane.WARNING_MESSAGE);
                    }
                });
                // Sets the listener to which the "Exit" sub menu is clicked
                exitMenuItem.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        System.out.println("Exit is clicked");
                        System.exit(0);
                    }
                });
                adminMenuItem.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        System.out.println("The administrator is clicked");
                        String pw = JOptionPane.showInputDialog("Please enter your password:");
                        int password = Integer.parseInt(pw);
                        if (password == 123456) {
                            JOptionPane.showMessageDialog(null, "Welcome back!", "welcome", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(null, "10/5000 \r\n" + 
                            		"Hum! You are not my master!", "warning", JOptionPane.WARNING_MESSAGE);
                        }
                    }
                });
                checkBoxMenuItem.addChangeListener(new ChangeListener() {
                    @Override
                    public void stateChanged(ChangeEvent e) {
                        System.out.println("Whether the check box is selected: " + checkBoxMenuItem.isSelected());
                    }
                });
                radio01.addChangeListener(new ChangeListener() {
                    @Override
                    public void stateChanged(ChangeEvent e) {
//                story.getContentPane().setVisible(true);
//                story.setBackground(Color.WHITE);
                    }
                });
                radio02.addChangeListener(new ChangeListener() {
                    @Override
                    public void stateChanged(ChangeEvent e) {
//                story.getContentPane().setVisible(true);
//                story.setBackground(Color.BLACK);
                    }
                });


                aboutMenu.addChangeListener(new ChangeListener() {
                    @Override
                    public void stateChanged(ChangeEvent e) {
                        JOptionPane.showMessageDialog(null, "<html><body><p align=\\\"center\\\">Please contact the developer if you have any questions。<br/>contact us：123@outlook.com</p></body></html>", "about", JOptionPane.INFORMATION_MESSAGE);
                    }
                });
                no.addActionListener(new ActionListener() {

                    @Override
                    public void actionPerformed(ActionEvent arg0) {
                        JOptionPane.showMessageDialog(null, "<html><body><p align=\"center\">You were spotted by the zombie in front of you<br/>Be Killed...</p></body></html>", "notice", JOptionPane.WARNING_MESSAGE);
                        System.exit(0);
                    }
                });
                yes.addActionListener(new ActionListener() {

                    @Override
                    public void actionPerformed(ActionEvent arg0) {
                        JFrame story2 = new JFrame("that's you story");
                        story2.setResizable(false);
                        story2.setSize(1000, 700);
                        story2.setVisible(true);
                        story2.setLocationRelativeTo(null);
                        story2.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
                        story2.setLayout(new BorderLayout());    //Set the layout for the Frame window to be BorderLayout
                        JLabel rule = new JLabel("<html><body><p align=\"center\">Welcome to the game of survival, young man<br/>Let us begin our escape！<br/>The rules are as follows：<br/>click the Button<br/>Due to the time, the lazy author only did a little, look forward to the author's update!</p></body></html>", JLabel.CENTER);
                        rule.setOpaque(true);
                        rule.setBackground(Color.black);
                        rule.setForeground(Color.white);
                        rule.setPreferredSize(new Dimension(1000, 100));
                        JLabel p2 = new JLabel(new ImageIcon("img/f.jpg"));
                        JPanel p3 = new JPanel() {
                            public void paintComponent(Graphics g) {
                                ImageIcon icon = new ImageIcon("img/bg.jpg");
                                // The image varies with the size of the form
                                g.drawImage(icon.getImage(), 0, 0, this.getSize().width, this.getSize().height, this);
                            }
                        };
                        JLabel txt = new JLabel("<html><body><p align=\"center\"><br/>When you get home, <br/>what do you want to do?<br/>[Lock the doors and Windows <br/>and draw the curtains]<br/><br/>[DO nothing]</p></body></html>");
                        txt.setFont(new Font("Dialog",Font.BOLD  , 15));
                        txt.setForeground(Color.white);
                        p3.add(txt);    //Add TXT to the JPanel container
                        txt.setOpaque(false);
                        JLabel p4 = new JLabel(new ImageIcon("img/s.jpg"));
                        Image image = new ImageIcon("img/3.jpg").getImage();
                        JPanel operate = new BackgroundPanel(image);
                        operate.setPreferredSize(new Dimension(1000, 100));
                        JButton yes = new JButton("Locked doors and Windows");
                        JButton no = new JButton("Do nothing");
                        operate.add(yes);
                        operate.add(no);
                        operate.validate();
                        operate.repaint();
                        //operate.revalidate();
                        story2.add(rule, BorderLayout.NORTH);
                        story2.add(p2, BorderLayout.WEST);
                        story2.add(p3, BorderLayout.CENTER);
                        story2.add(p4, BorderLayout.EAST);
                        story2.add(operate, BorderLayout.SOUTH);
                        JMenuBar menuBar = new JMenuBar();
                        JMenu fileMenu = new JMenu("file");
                        JMenu editMenu = new JMenu("compile");
                        JMenu elseMenu = new JMenu("additional");
                        JMenu aboutMenu = new JMenu("about");
                        // A level menu is added to the menu bar
                        menuBar.add(fileMenu);
                        menuBar.add(editMenu);
                        menuBar.add(elseMenu);
                        menuBar.add(aboutMenu);
                        JMenuItem newMenuItem = new JMenuItem("New Game");
                        JMenuItem attributeMenuItem = new JMenuItem("attribute");
                        JMenuItem exitMenuItem = new JMenuItem("Exit");
                        // Sub menus are added to the primary menu
                        fileMenu.add(newMenuItem);
                        fileMenu.add(attributeMenuItem);
                        fileMenu.addSeparator();       // Add a divider
                        fileMenu.add(exitMenuItem);
                        JMenuItem adminMenuItem = new JMenuItem("Administrator mode");
                        JMenuItem pasteMenuItem = new JMenuItem("To be determined");
                        // Sub menus are added to the primary menu
                        editMenu.add(adminMenuItem);
                        editMenu.add(pasteMenuItem);
                        final JCheckBoxMenuItem checkBoxMenuItem = new JCheckBoxMenuItem("Whether to turn on the music");
                        final JRadioButtonMenuItem radio01 = new JRadioButtonMenuItem("In the daytime mode", true);
                        final JRadioButtonMenuItem radio02 = new JRadioButtonMenuItem("In the night mode");
                        // Sub menus are added to the primary menu
                        elseMenu.add(checkBoxMenuItem);
                        elseMenu.addSeparator();                // Add a divider
                        elseMenu.add(radio01);
                        elseMenu.add(radio02);
                        // Two of these are radio button sub menus. To make radio buttons look like radio buttons, you need to put them into a group of buttons
                        ButtonGroup btnGroup = new ButtonGroup();
                        btnGroup.add(radio01);
                        btnGroup.add(radio02);
                        // Default the first radio button sub menu is selected
                        radio01.setSelected(true);
                        newMenuItem.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                System.out.println("New start is clicked");
                            }
                        });
                        // Sets the listener to which the "Open" sub menu is clicked
                        attributeMenuItem.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                System.out.println("Properties are clicked");
                                JOptionPane.showMessageDialog(null, "To develop", "warning", JOptionPane.WARNING_MESSAGE);
                            }
                        });
                        // Sets the listener to which the "Exit" sub menu is clicked
                        exitMenuItem.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                System.out.println("Exit is clicked");
                                System.exit(0);
                            }
                        });
                        adminMenuItem.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                System.out.println("The administrator is clicked");
                                String pw = JOptionPane.showInputDialog("Please enter your password:");
                                int password = Integer.parseInt(pw);
                                if (password == 123456) {
                                    JOptionPane.showMessageDialog(null, "Welcome back!", "welcome", JOptionPane.INFORMATION_MESSAGE);
                                } else {
                                    JOptionPane.showMessageDialog(null, "10/5000 \r\n" + 
                                    		"Hum! You are not my master!", "warning", JOptionPane.WARNING_MESSAGE);
                                }
                            }
                        });
                        checkBoxMenuItem.addChangeListener(new ChangeListener() {
                            @Override
                            public void stateChanged(ChangeEvent e) {
                                System.out.println("Whether the check box is selected: " + checkBoxMenuItem.isSelected());
                            }
                        });
                        radio01.addChangeListener(new ChangeListener() {
                            @Override
                            public void stateChanged(ChangeEvent e) {
//                story2.getContentPane().setVisible(true);
//                story2.setBackground(Color.WHITE);
                            }
                        });
                        radio02.addChangeListener(new ChangeListener() {
                            @Override
                            public void stateChanged(ChangeEvent e) {
//                story2.getContentPane().setVisible(true);
//                story2.setBackground(Color.BLACK);
                            }
                        });


                        aboutMenu.addChangeListener(new ChangeListener() {
                            @Override
                            public void stateChanged(ChangeEvent e) {
                                JOptionPane.showMessageDialog(null, "<html><body><p align=\\\"center\\\">Please contact the developer if you have any questions。<br/>contact us：123@outlook.com</p></body></html>", "about", JOptionPane.INFORMATION_MESSAGE);
                            }
                        });
                        no.addActionListener(new ActionListener() {

                            @Override
                            public void actionPerformed(ActionEvent arg0) {
                                JOptionPane.showMessageDialog(null, "<html><body><p align=\"center\">You were found by a zombie<br/> who stormed into your house<br/>You were bitten to death...</p></body></html>", "notice", JOptionPane.WARNING_MESSAGE);
                                System.exit(0);
                            }
                        });
                        yes.addActionListener(new ActionListener() {

                            @Override
                            public void actionPerformed(ActionEvent arg0) {
                                JFrame story3 = new JFrame("that's you story");
                                story3.setResizable(false);
                                story3.setSize(1000, 700);
                                story3.setVisible(true);
                                story3.setLocationRelativeTo(null);
                                story3.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
                                story3.setLayout(new BorderLayout());    //Set the layout for the Frame window to be BorderLayout
                                JLabel rule = new JLabel("<html><body><p align=\"center\">Welcome to the game of survival, young man<br/>Let us begin our escape！<br/>The rules are as follows：<br/>click the Button<br/>Due to the time, the lazy author only did a little, look forward to the author's update!</p></body></html>", JLabel.CENTER);
                                rule.setOpaque(true);
                                rule.setBackground(Color.black);
                                rule.setForeground(Color.white);
                                rule.setPreferredSize(new Dimension(1000, 100));
                                JLabel p2 = new JLabel(new ImageIcon("img/f.jpg"));
                                JPanel p3 = new JPanel() {
                                    public void paintComponent(Graphics g) {
                                        ImageIcon icon = new ImageIcon("img/bg.jpg");
                                        // The image varies with the size of the form
                                        g.drawImage(icon.getImage(), 0, 0, this.getSize().width, this.getSize().height, this);
                                    }
                                };
                                JLabel txt = new JLabel("<html><body><p align=\"center\"><br/>Suddenly, your phone rings<br/>And then you will：<br/>[To answer the phone]<br/><br/>[To turn it off.]</p></body></html>");
                                txt.setFont(new Font("Dialog",Font.BOLD  , 15));
                                txt.setForeground(Color.white);
                                p3.add(txt);    //Add TXT to the JPanel container
                                txt.setOpaque(false);
                                JLabel p4 = new JLabel(new ImageIcon("img/s.jpg"));
                                Image image = new ImageIcon("img/3.jpg").getImage();
                                JPanel operate = new BackgroundPanel(image);
                                operate.setPreferredSize(new Dimension(1000, 100));
                                JButton yes = new JButton("To answer the phone");
                                JButton no = new JButton("To turn it off");
                                operate.add(yes);
                                operate.add(no);
                                operate.validate();
                                operate.repaint();
                                //operate.revalidate();
                                story3.add(rule, BorderLayout.NORTH);
                                story3.add(p2, BorderLayout.WEST);
                                story3.add(p3, BorderLayout.CENTER);
                                story3.add(p4, BorderLayout.EAST);
                                story3.add(operate, BorderLayout.SOUTH);
                                JMenuBar menuBar = new JMenuBar();
                                JMenu fileMenu = new JMenu("file");
                                JMenu editMenu = new JMenu("compile");
                                JMenu elseMenu = new JMenu("additional");
                                JMenu aboutMenu = new JMenu("about");
                                // A level menu is added to the menu bar
                                menuBar.add(fileMenu);
                                menuBar.add(editMenu);
                                menuBar.add(elseMenu);
                                menuBar.add(aboutMenu);
                                JMenuItem newMenuItem = new JMenuItem("New Game");
                                JMenuItem attributeMenuItem = new JMenuItem("attribute");
                                JMenuItem exitMenuItem = new JMenuItem("Exit");
                                // Sub menus are added to the primary menu
                                fileMenu.add(newMenuItem);
                                fileMenu.add(attributeMenuItem);
                                fileMenu.addSeparator();       // Add a divider
                                fileMenu.add(exitMenuItem);
                                JMenuItem adminMenuItem = new JMenuItem("Administrator mode");
                                JMenuItem pasteMenuItem = new JMenuItem("To be determined");
                                // Sub menus are added to the primary menu
                                editMenu.add(adminMenuItem);
                                editMenu.add(pasteMenuItem);
                                final JCheckBoxMenuItem checkBoxMenuItem = new JCheckBoxMenuItem("Whether to turn on the music");
                                final JRadioButtonMenuItem radio01 = new JRadioButtonMenuItem("In the daytime mode", true);
                                final JRadioButtonMenuItem radio02 = new JRadioButtonMenuItem("In the night mode");
                                // Sub menus are added to the primary menu
                                elseMenu.add(checkBoxMenuItem);
                                elseMenu.addSeparator();                // Add a divider
                                elseMenu.add(radio01);
                                elseMenu.add(radio02);
                                // Two of these are radio button sub menus. To make radio buttons look like radio buttons, you need to put them into a group of buttons
                                ButtonGroup btnGroup = new ButtonGroup();
                                btnGroup.add(radio01);
                                btnGroup.add(radio02);
                                // Default the first radio button sub menu is selected
                                radio01.setSelected(true);
                                newMenuItem.addActionListener(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        System.out.println("New start is clicked");
                                    }
                                });
                                // Sets the listener to which the "Open" sub menu is clicked
                                attributeMenuItem.addActionListener(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        System.out.println("Properties are clicked");
                                        JOptionPane.showMessageDialog(null, "To develop", "warning", JOptionPane.WARNING_MESSAGE);
                                    }
                                });
                                // Sets the listener to which the "Exit" sub menu is clicked
                                exitMenuItem.addActionListener(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        System.out.println("Exit is clicked");
                                        System.exit(0);
                                    }
                                });
                                adminMenuItem.addActionListener(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        System.out.println("The administrator is clicked");
                                        String pw = JOptionPane.showInputDialog("Please enter your password:");
                                        int password = Integer.parseInt(pw);
                                        if (password == 123456) {
                                            JOptionPane.showMessageDialog(null, "Welcome back!", "welcome", JOptionPane.INFORMATION_MESSAGE);
                                        } else {
                                            JOptionPane.showMessageDialog(null, "10/5000 \r\n" + 
                                            		"Hum! You are not my master!", "warning", JOptionPane.WARNING_MESSAGE);
                                        }
                                    }
                                });
                                checkBoxMenuItem.addChangeListener(new ChangeListener() {
                                    @Override
                                    public void stateChanged(ChangeEvent e) {
                                        System.out.println("Whether the check box is selected: " + checkBoxMenuItem.isSelected());
                                    }
                                });
                                radio01.addChangeListener(new ChangeListener() {
                                    @Override
                                    public void stateChanged(ChangeEvent e) {
//                story3.getContentPane().setVisible(true);
//                story3.setBackground(Color.WHITE);
                                    }
                                });
                                radio02.addChangeListener(new ChangeListener() {
                                    @Override
                                    public void stateChanged(ChangeEvent e) {
//                story3.getContentPane().setVisible(true);
//                story3.setBackground(Color.BLACK);
                                    }
                                });


                                aboutMenu.addChangeListener(new ChangeListener() {
                                    @Override
                                    public void stateChanged(ChangeEvent e) {
                                        JOptionPane.showMessageDialog(null, "<html><body><p align=\\\"center\\\">Please contact the developer if you have any questions。<br/>contact us：123@outlook.com</p></body></html>", "about", JOptionPane.INFORMATION_MESSAGE);
                                    }
                                });
                                no.addActionListener(new ActionListener() {

                                    @Override
                                    public void actionPerformed(ActionEvent arg0) {
                                        JOptionPane.showMessageDialog(null, "<html><body><p align=\"center\">You're missing out on important information.<br/>You're trapped in this room forever, until you become a mummified corpse...</p></body></html>", "notice", JOptionPane.WARNING_MESSAGE);
                                        System.exit(0);
                                    }
                                });
                                yes.addActionListener(new ActionListener() {

                                    @Override
                                    public void actionPerformed(ActionEvent arg0) {
                                        JFrame story4 = new JFrame("that's you story");
                                        story4.setResizable(false);
                                        story4.setSize(1000, 700);
                                        story4.setVisible(true);
                                        story4.setLocationRelativeTo(null);
                                        story4.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
                                        story4.setLayout(new BorderLayout());    //Set the layout for the Frame window to be BorderLayout
                                        JLabel rule = new JLabel("<html><body><p align=\"center\">Welcome to the game of survival, young man<br/>Let us begin our escape！<br/>The rules are as follows：<br/>click the Button<br/>Due to the time, the lazy author only did a little, look forward to the author's update!</p></body></html>", JLabel.CENTER);
                                        rule.setOpaque(true);
                                        rule.setBackground(Color.black);
                                        rule.setForeground(Color.white);
                                        rule.setPreferredSize(new Dimension(1000, 100));
                                        JLabel p2 = new JLabel(new ImageIcon("img/f.jpg"));
                                        JPanel p3 = new JPanel() {
                                            public void paintComponent(Graphics g) {
                                                ImageIcon icon = new ImageIcon("img/bg.jpg");
                                                // The image varies with the size of the form
                                                g.drawImage(icon.getImage(), 0, 0, this.getSize().width, this.getSize().height, this);
                                            }
                                        };
                                        JLabel txt = new JLabel("<html><body><p align=\"center\"><br/>It was your parents who called.<br/>They explained to you what was going on outside<br/>They told you to find your own way to the evacuation site<br/>[Let's go]<br/>[Too dangerous, sleep now]</p></body></html>");
                                        txt.setFont(new Font("Dialog",Font.BOLD  , 15));
                                        txt.setForeground(Color.white);
                                        p3.add(txt);    //Add TXT to the JPanel container
                                        txt.setOpaque(false);
                                        JLabel p4 = new JLabel(new ImageIcon("img/s.jpg"));
                                        Image image = new ImageIcon("img/3.jpg").getImage();
                                        JPanel operate = new BackgroundPanel(image);
                                        operate.setPreferredSize(new Dimension(1000, 100));
                                        JButton yes = new JButton("Let's go");
                                        JButton no = new JButton("Sleep now");
                                        operate.add(yes);
                                        operate.add(no);
                                        operate.validate();
                                        operate.repaint();
                                        //operate.revalidate();
                                        story4.add(rule, BorderLayout.NORTH);
                                        story4.add(p2, BorderLayout.WEST);
                                        story4.add(p3, BorderLayout.CENTER);
                                        story4.add(p4, BorderLayout.EAST);
                                        story4.add(operate, BorderLayout.SOUTH);
                                        JMenuBar menuBar = new JMenuBar();
                                        JMenu fileMenu = new JMenu("file");
                                        JMenu editMenu = new JMenu("compile");
                                        JMenu elseMenu = new JMenu("additional");
                                        JMenu aboutMenu = new JMenu("about");
                                        // A level menu is added to the menu bar
                                        menuBar.add(fileMenu);
                                        menuBar.add(editMenu);
                                        menuBar.add(elseMenu);
                                        menuBar.add(aboutMenu);
                                        JMenuItem newMenuItem = new JMenuItem("New Game");
                                        JMenuItem attributeMenuItem = new JMenuItem("attribute");
                                        JMenuItem exitMenuItem = new JMenuItem("Exit");
                                        // Sub menus are added to the primary menu
                                        fileMenu.add(newMenuItem);
                                        fileMenu.add(attributeMenuItem);
                                        fileMenu.addSeparator();       // Add a divider
                                        fileMenu.add(exitMenuItem);
                                        JMenuItem adminMenuItem = new JMenuItem("Administrator mode");
                                        JMenuItem pasteMenuItem = new JMenuItem("To be determined");
                                        // Sub menus are added to the primary menu
                                        editMenu.add(adminMenuItem);
                                        editMenu.add(pasteMenuItem);
                                        final JCheckBoxMenuItem checkBoxMenuItem = new JCheckBoxMenuItem("Whether to turn on the music");
                                        final JRadioButtonMenuItem radio01 = new JRadioButtonMenuItem("In the daytime mode", true);
                                        final JRadioButtonMenuItem radio02 = new JRadioButtonMenuItem("In the night mode");
                                        // Sub menus are added to the primary menu
                                        elseMenu.add(checkBoxMenuItem);
                                        elseMenu.addSeparator();                // Add a divider
                                        elseMenu.add(radio01);
                                        elseMenu.add(radio02);
                                        // Two of these are radio button sub menus. To make radio buttons look like radio buttons, you need to put them into a group of buttons
                                        ButtonGroup btnGroup = new ButtonGroup();
                                        btnGroup.add(radio01);
                                        btnGroup.add(radio02);
                                        // Default the first radio button sub menu is selected
                                        radio01.setSelected(true);
                                        newMenuItem.addActionListener(new ActionListener() {
                                            @Override
                                            public void actionPerformed(ActionEvent e) {
                                                System.out.println("New start is clicked");
                                            }
                                        });
                                        // Sets the listener to which the "Open" sub menu is clicked
                                        attributeMenuItem.addActionListener(new ActionListener() {
                                            @Override
                                            public void actionPerformed(ActionEvent e) {
                                                System.out.println("Properties are clickedvv");
                                                JOptionPane.showMessageDialog(null, "To develop", "warning", JOptionPane.WARNING_MESSAGE);
                                            }
                                        });
                                        // Sets the listener to which the "Exit" sub menu is clicked
                                        exitMenuItem.addActionListener(new ActionListener() {
                                            @Override
                                            public void actionPerformed(ActionEvent e) {
                                                System.out.println("Exit is clicked");
                                                System.exit(0);
                                            }
                                        });
                                        adminMenuItem.addActionListener(new ActionListener() {
                                            @Override
                                            public void actionPerformed(ActionEvent e) {
                                                System.out.println("The administrator is clicked");
                                                String pw = JOptionPane.showInputDialog("Please enter your password:");
                                                int password = Integer.parseInt(pw);
                                                if (password == 123456) {
                                                    JOptionPane.showMessageDialog(null, "Welcome back! ", "welcome", JOptionPane.INFORMATION_MESSAGE);
                                                } else {
                                                    JOptionPane.showMessageDialog(null, "10/5000 \r\n" + 
                                                    		"Hum! You are not my master!", "warning", JOptionPane.WARNING_MESSAGE);
                                                }
                                            }
                                        });
                                        checkBoxMenuItem.addChangeListener(new ChangeListener() {
                                            @Override
                                            public void stateChanged(ChangeEvent e) {
                                                System.out.println("Whether the check box is selected: " + checkBoxMenuItem.isSelected());
                                            }
                                        });
                                        radio01.addChangeListener(new ChangeListener() {
                                            @Override
                                            public void stateChanged(ChangeEvent e) {
//                story4.getContentPane().setVisible(true);
//                story4.setBackground(Color.WHITE);
                                            }
                                        });
                                        radio02.addChangeListener(new ChangeListener() {
                                            @Override
                                            public void stateChanged(ChangeEvent e) {
//                story4.getContentPane().setVisible(true);
//                story4.setBackground(Color.BLACK);
                                            }
                                        });


                                        aboutMenu.addChangeListener(new ChangeListener() {
                                            @Override
                                            public void stateChanged(ChangeEvent e) {
                                                JOptionPane.showMessageDialog(null, "<html><body><p align=\\\"center\\\">Please contact the developer if you have any questions.<br/>contact us：123@outlook.com</p></body></html>", "about", JOptionPane.INFORMATION_MESSAGE);
                                            }
                                        });
                                        no.addActionListener(new ActionListener() {

                                            @Override
                                            public void actionPerformed(ActionEvent arg0) {
                                                JOptionPane.showMessageDialog(null, "<html><body><p align=\"center\">You missed your last chance to save your life.<br/>You're trapped in this room forever, until you become a mummified corpse...</p></body></html>", "notice", JOptionPane.WARNING_MESSAGE);
                                                System.exit(0);
                                            }
                                        });
                                        yes.addActionListener(new ActionListener() {

                                            @Override
                                            public void actionPerformed(ActionEvent arg0) {
                                                JOptionPane.showMessageDialog(null, "<html><body><p align=\"center\">You opem the door<br/>An epic adventure begins...</p></body></html>", "about", JOptionPane.INFORMATION_MESSAGE);
                                                System.exit(0);
                                            }
                                        });
                                        story3.dispose();
                                    }
                                });
                                story2.dispose();
                            }
                        });
                        story1.dispose();
                    }
                });
                story.dispose();
            }
        });
        story.setJMenuBar(menuBar);
    }
}

class BackgroundPanel extends JPanel {
    private static final long serialVersionUID = -6352788025440244338L;
    private Image image = null;
    public BackgroundPanel(Image image) {
        this.image = image;
    }
    // Fixing the background image allows the JPanel to add other components to the image
    protected void paintComponent(Graphics g) {
        g.drawImage(image, 0, 0, this.getWidth(), this.getHeight(), this);
    }

}
